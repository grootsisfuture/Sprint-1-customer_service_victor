package com.tns.certificateservice;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Certificate_Service_Repository extends JpaRepository<Certificate, Integer> 
{

}
